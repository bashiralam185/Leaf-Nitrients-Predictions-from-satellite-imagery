# Leaf-Nitrients-Predictions-from-satellite-imagery
Upwork project
